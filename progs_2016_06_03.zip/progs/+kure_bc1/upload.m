function upload(setNoV, expNoV)
% Upload mat files for several sets
% -----------------------------------------

% if nargin == 1
%    expNoV = 1;
% end

ans1 = input('Upload these sets?  ', 's');
if ~strcmpi(ans1, 'yes')
   return
end

kure_bc1.updownload(setNoV, expNoV, 'up')

end