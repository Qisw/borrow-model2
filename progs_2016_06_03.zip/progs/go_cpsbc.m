function go_cpsbc

cS = const_bc1([]);

% CPS routines
addpath(cS.cpsProgDir);
init_cpsbc;


end