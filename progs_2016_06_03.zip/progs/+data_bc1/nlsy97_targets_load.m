function n97S = nlsy97_targets_load(cS)

n97S = load(cS.nlsy97Fn);
n97S = n97S.all_targets;

end