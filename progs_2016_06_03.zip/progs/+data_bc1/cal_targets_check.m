function cal_targets_check(setNo)

cS = const_bc1(setNo);
tgS = var_load_bc1(cS.vCalTargets, cS);





end