function temp1

parfor i1 = 1 : 10
   pause(0.5);
   xRand = random_lh.rand_time;
   disp(xRand);
end


end