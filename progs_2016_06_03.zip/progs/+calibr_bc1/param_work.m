function workS = param_work(cS)
% Work parameters

workS.nk = 50;


end